import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronRight, TrendingUp, Zap, Users, Calendar } from "lucide-react";

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <Image
          src="https://images.unsplash.com/photo-1504280390367-361c6d9f38f4"
          alt="Beautiful campground at sunset"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8">
          <h1 className="font-montserrat text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight mb-6">
            Transform Your Campground into a
            <span className="text-green-400"> Profit-Generating Paradise</span>
          </h1>
          <p className="text-xl sm:text-2xl mb-8 max-w-3xl mx-auto">
            Boost occupancy rates, automate marketing, and streamline reservations with proven strategies
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              Get Free Consultation
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              View Case Studies
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl mb-4">
              Transform Your Campground Operations
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Join hundreds of successful campground owners who have revolutionized their business with our proven strategies
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: TrendingUp,
                title: "Revenue Growth",
                description: "Average 40% increase in annual revenue for our clients",
              },
              {
                icon: Zap,
                title: "Automation",
                description: "Save 20+ hours per week with smart automation systems",
              },
              {
                icon: Users,
                title: "Guest Experience",
                description: "Improve guest satisfaction scores by up to 60%",
              },
              {
                icon: Calendar,
                title: "Occupancy Rates",
                description: "Achieve 85%+ occupancy rates during peak season",
              },
            ].map((benefit, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <benefit.icon className="h-12 w-12 text-green-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl mb-4">
              Trusted by Leading Campground Owners
            </h2>
            <p className="text-xl text-gray-600">
              See the real results our clients have achieved
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                quote: "Our revenue increased by 45% in just six months after implementing their strategies.",
                author: "Sarah Johnson",
                role: "Owner, Pine Valley Campground",
                image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
              },
              {
                quote: "The automation systems they implemented saved us countless hours in administrative work.",
                author: "Michael Chen",
                role: "Manager, Riverside Camping Resort",
                image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
              },
              {
                quote: "Best investment we've made. Our occupancy rates are at an all-time high.",
                author: "David Miller",
                role: "Owner, Mountain View Campsite",
                image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e",
              },
            ].map((testimonial, index) => (
              <Card key={index} className="p-8">
                <div className="flex items-center mb-6">
                  <Image
                    src={testimonial.image}
                    alt={testimonial.author}
                    width={48}
                    height={48}
                    className="rounded-full"
                  />
                  <div className="ml-4">
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">&ldquo;{testimonial.quote}&rdquo;</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-green-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Your Campground?
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Book your free consultation today and discover how we can help you maximize your campground's potential
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link href="/contact" className="inline-flex items-center">
              Get Started Today
              <ChevronRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </>
  );
}