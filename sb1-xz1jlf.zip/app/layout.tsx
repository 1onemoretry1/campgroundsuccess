import './globals.css';
import type { Metadata } from 'next';
import { Inter, Montserrat } from 'next/font/google';
import { ThemeProvider } from '@/components/theme-provider';
import { Navigation } from '@/components/navigation';
import { Footer } from '@/components/footer';
import { Toaster } from '@/components/ui/sonner';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const montserrat = Montserrat({ subsets: ['latin'], variable: '--font-montserrat' });

export const metadata: Metadata = {
  title: {
    template: '%s | Campground Success',
    default: 'Campground Success - Transform Your Campground into a Profit-Generating Paradise',
  },
  description: 'Expert consulting for campground owners to maximize revenue, automate marketing, and optimize operations. Transform your campground business with proven strategies.',
  keywords: ['campground management consulting', 'campground revenue optimization', 'campground marketing automation', 'reservation system optimization', 'campground occupancy rate improvement', 'campground business consulting'],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://campgroundsuccess.com',
    siteName: 'Campground Success',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Campground Success',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Campground Success',
    description: 'Transform Your Campground into a Profit-Generating Paradise',
    images: ['/og-image.jpg'],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#2F855A" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": "Campground Success",
              "description": "Expert consulting for campground owners to maximize revenue and optimize operations.",
              "url": "https://campgroundsuccess.com",
              "telephone": "+1-555-123-4567",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "123 Nature Way",
                "addressLocality": "Mountain View",
                "addressRegion": "CA",
                "postalCode": "94040",
                "addressCountry": "US"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 37.386051,
                "longitude": -122.083855
              },
              "sameAs": [
                "https://facebook.com/campgroundsuccess",
                "https://twitter.com/campgroundsuccess",
                "https://linkedin.com/company/campgroundsuccess"
              ]
            })
          }}
        />
      </head>
      <body className={`${inter.variable} ${montserrat.variable} font-sans`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <Navigation />
          <main className="min-h-screen">{children}</main>
          <Footer />
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}